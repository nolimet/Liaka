﻿using UnityEngine;
using System.Collections;

public class Axis  {

    public const string Horizontal = "Horizontal",
                    Vertical = "Vertical",
                    Fire = "Fire1";
}
