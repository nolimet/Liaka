﻿using UnityEngine;
using System.Collections;

public class Startup : MonoBehaviour {

	void LateUpdate()
    {
        Application.LoadLevel(1);
    }
}
