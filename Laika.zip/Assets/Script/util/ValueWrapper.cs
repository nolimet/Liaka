﻿namespace util
{
    [System.Serializable]
    public class ValueWrapper<T>
    {
        public T value { get; set; }
    }
}
