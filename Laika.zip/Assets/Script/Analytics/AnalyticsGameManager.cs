﻿using UnityEngine;
//using UnityEngine.Analytics;
////using GameAnalyticsSDK;
//using System.Collections;
//using System.Collections.Generic;

public class AnalyticsGameManager : MonoBehaviour
{
    //public void OnLevelWasLoaded(int level)
    //{
    //    Analytics.CustomEvent("LevelSwitch", new Dictionary<string, object>
    //            {
    //                {"level_id", "Lvl " + level }
    //            });
    //}
}
